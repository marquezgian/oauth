{module.exports = {
    google:{
        clientID: '625820153270-3te4kkbu7srbla7t3f1d3mqked7frco7.apps.googleusercontent.com', 
        clientSecret: 'FutaogkBp8czlvWIp7wGmh7x'
    },
    postgresdb:
        {
        user: 'tmhrscanfkgaqo',
        host: 'ec2-174-129-33-217.compute-1.amazonaws.com',
        database: 'dd0osss9gcmbdp',
        password: '6e9322a54a86f6054a7a6b6c3e0895e2086b27e5f53be11986ddb9b6d11f6262',
        port:'5432',
        ssl:true,
    },
    session:{
        cookieKey: 'thisismyuniquecookiekey'
    }
};}


